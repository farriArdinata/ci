<?php

class Welcome extends CI_Controller {

	function __constrcut(){

		parent::__constrcut();
		$this->load->model(m_login);
	}

	function index()
	{
		$this->load->view('welcome_message');
	}

	function login(){
		$emailAddress = $this->input->post('emailAddress');
		$password = $this->input->post('password');

		$where = array(
			'emailAddress' => $emailAddress,
			'password' => $password
		);

		$cek = $this->m_login->cek_login("admin",$where)->num_rows();

		if ($cek > 0) {
			$data_session = array(
				'emailAddress' => $emailAddress,
				'status' => "Login"
			);

			$this->session->set_userdata($data_session);
			redirect(base_url("admin"));

		}else{
			echo "Email atau password salah";
		}

		function logout(){
			$this->session->sess_destroy();
			redirect(base_url(welcome));
		}

	}
}
