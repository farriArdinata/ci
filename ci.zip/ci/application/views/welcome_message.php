<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title>Login Form</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	</head>
	<body>

				<nav class="navbar navbar-light bg-light">
				  <span class="navbar-brand mb-0 h1">Form Login</span>
				</nav>
<br>
				<div class="container">
				<form class="" action="<?php echo base_url('welcome/login');?>" method="post">
					<div class="row justify-content-center">
					<div class="card" style="width: 18rem;">
					  <img class="card-img-top" src="https://png.pngtree.com/png-vector/20191003/ourlarge/pngtree-user-login-or-authenticate-icon-on-gray-background-flat-icon-ve-png-image_1786166.jpg" alt="Card image cap">
					  <div class="card-body">
							<div class="form-group">
								<label for="emailAddress">Email Address</label>
								<input type="email" name="emailAddress" placeholder="name@example.com" class="form-control">
							</div>

							<div class="form-group">
								<label for="password">Password</label>
								<input type="password" name="password" placeholder="****" class="form-control">
							</div>

							<input type="submit" value="Login" class="btn btn-success">
							<input type="reset" name="reset" value="Reset" class="btn btn-danger">
					  </div>
					</div>
				</div>
				</form>
			</div>
	</body>
</html>
